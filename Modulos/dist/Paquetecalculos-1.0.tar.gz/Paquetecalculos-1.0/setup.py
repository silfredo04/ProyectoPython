from setuptools import setup



setup(
    name="Paquetecalculos",
    version="1.0",
    description="Realiza calculos matematicos",
    author="Silfredo orozco",
    author_email="silfredoantonio1991@hotmail.com",
    url="www.silfredooro.com",
    packages=["Calculos","Calculos.Redondeo_potencias"]
)
